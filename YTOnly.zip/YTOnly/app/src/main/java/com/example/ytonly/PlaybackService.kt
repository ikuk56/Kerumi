package com.example.ytonly

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import androidx.core.app.ServiceCompat

class PlaybackService : Service() {

    companion object {
        @Volatile var instance: PlaybackService? = null
        private const val CH = "yt_playback"
        private const val ID = 1
        private const val ACTION_TOGGLE = "com.example.ytonly.TOGGLE"
    }

    private val main = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private var foreground = false
    private var isPlaying = false
    private var title = "YouTube"
    private lateinit var session: MediaSession

    // Si el video lleva 15 s en pausa, deja de ser servicio en primer plano (la notificación queda con "Reproducir")
    private val demote = Runnable {
        if (!isPlaying && foreground) {
            stopForeground(STOP_FOREGROUND_DETACH)
            foreground = false
            refreshNotification()
            wl?.takeIf { it.isHeld }?.release()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Reproducción", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "YTOnly").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { command(true) }
                override fun onPause() { command(false) }
            })
            isActive = true
        }
        updateSession()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE) command(!isPlaying)
        return START_NOT_STICKY
    }

    private fun command(play: Boolean) {
        WebHolder.js(
            if (play) "window.__ytUserPause=false;document.querySelector('video')?.play()"
            else "window.__ytUserPause=true;document.querySelector('video')?.pause()"
        )
    }

    private fun updateSession() {
        val state = PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE)
            .setState(
                if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f
            )
            .build()
        session.setPlaybackState(state)
        session.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title).build())
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggle = PendingIntent.getService(
            this, 1, Intent(this, PlaybackService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(
            this, if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        val action = Notification.Action.Builder(icon, if (isPlaying) "Pausar" else "Reproducir", toggle).build()
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (isPlaying) "Reproduciendo" else "En pausa")
            .setContentIntent(open)
            .addAction(action)
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0))
            .setOngoing(isPlaying)
            .build()
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java).notify(ID, notification())
    }

    fun setTitle(t: String) {
        main.post {
            val n = t.removeSuffix(" - YouTube").ifBlank { "YouTube" }
            if (n != title) {
                title = n
                updateSession()
                if (foreground) refreshNotification()
            }
        }
    }

    fun setPlaying(p: Boolean) {
        main.post {
            isPlaying = p
            updateSession()
            main.removeCallbacks(demote)
            if (p) {
                if (!foreground) {
                    try {
                        ServiceCompat.startForeground(this, ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                        foreground = true
                    } catch (_: Exception) {}
                } else {
                    refreshNotification()
                }
                if (wl?.isHeld != true) {
                    wl = getSystemService(PowerManager::class.java)
                        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytonly:play")
                        .apply { acquire(6 * 60 * 60 * 1000L) }
                }
            } else {
                if (foreground) refreshNotification()
                main.postDelayed(demote, 15000)
            }
        }
    }

    /** Se dispara al quitar la app de Recientes: limpia todo y mata el proceso. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        wipe()
        wl?.takeIf { it.isHeld }?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java).cancel(ID)
        stopSelf()
        main.postDelayed({ Process.killProcess(Process.myPid()) }, 1200)
        super.onTaskRemoved(rootIntent)
    }

    private fun wipe() {
        try {
            WebView(applicationContext).apply { clearCache(true); clearHistory(); destroy() }
        } catch (_: Throwable) {}
        try { WebStorage.getInstance().deleteAllData() } catch (_: Throwable) {}
        val cm = CookieManager.getInstance()
        if (Config.KEEP_LOGIN) cm.removeSessionCookies(null) else cm.removeAllCookies(null)
        cm.flush()
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(demote)
        wl?.takeIf { it.isHeld }?.release()
        try { session.release() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
